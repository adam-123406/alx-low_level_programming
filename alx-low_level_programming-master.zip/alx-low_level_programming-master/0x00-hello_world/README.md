c hello world
